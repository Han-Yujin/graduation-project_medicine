<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>footer</title>
	<style type="text/css">
	    body{min-width:950px; text-align:center;}

		#footer { height:50px; background-size:contain; margin:3px; padding: 3px; }
		#footer_up { margin-bottom:2px; }
		#footer_down { margin-top:2px;}
		#footer { color:#0f0101; padding:0px; font-size:13px; text-indent: 0.5em;}
		.footer_box {display: inline-block; height:53px; white-space:nowrap; }
		#footer	ul {list-style:none; display:inline-block; margin-left:5px; margin-right:5px;}

	</style>	
</head>
<body>
	<hr id ="footer_up">
		<div id="footer">
			<div class="footer_box">
				<ul>
					<li>만든사람 </li>
					<li>한유진</ln>
				</ul>
				<ul>
					<li>이메일</ln>
					<li>yujin00530@naver.com</ln>
				</ul>
				<ul>
					<li></ln>
					<li></ln>
				</ul>
			</div>	
		</div>
	<hr id="footer_down">
</body>
</html>
