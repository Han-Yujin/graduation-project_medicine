<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="css/main.css">
        <title>medicine information</title>
        
    </head>
    <body> 
    
    <?php include "main.php";
    ?>


    </body>
    <br><br><br><br><br><br>
    <footer>
    	<?php include "footer.php";?>
    </footer>
    
   
</html>